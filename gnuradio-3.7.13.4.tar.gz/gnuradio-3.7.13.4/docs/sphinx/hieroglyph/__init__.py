# We only need to expose the setup function to Sphinx

from .hieroglyph import setup
from .version import __version__

__author__ = 'Robert Smallshire'