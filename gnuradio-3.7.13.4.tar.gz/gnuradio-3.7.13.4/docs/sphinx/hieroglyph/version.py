'''Specification of the hieroglyph version'''

__version__ = '0.6'
