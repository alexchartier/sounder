gnuradio.wxgui
==============

.. automodule:: gnuradio.wxgui

.. autoblock:: gnuradio.wxgui.histo_sink_f
.. autoblock:: gnuradio.wxgui.oscope_sink_f
