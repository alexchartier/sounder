gnuradio.video_sdl
==================

.. automodule:: gnuradio.video_sdl

.. autoblock:: gnuradio.video_sdl.sink_s
.. autoblock:: gnuradio.video_sdl.sink_uc
