namespace std
{
  /*!
   * \brief vector documentation stub
   *
   * \warning
   * This isn't the real vector template.  It's just enough to get doxygen
   * to draw pretty collaboration diagrams.
   */
  template<class T> class vector
  {
  public:
    T		*p;
  };

} // namespace std
