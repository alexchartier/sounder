// library version, increment only on C interface changes
#define DIGITAL_RF_VERSION "2.1.0"
